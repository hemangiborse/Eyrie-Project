package com.example.eyrie;

public class list<T> {
}
