package com.example.eyrie;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder>{
    private list<CategoryModel> categoryModellist;

    public CategoryAdapter(list<CategoryModel> categoryModellist) {
        this.categoryModellist = categoryModellist;
    }

    @NonNull
    @Override
    public CategoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()) .inflate(R.layout.category_item,viewGroup,false);

        return new ViewHolder(View);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryAdapter.ViewHolder holder, int position) {
        String icon = categoryModellist.get(position).getCategoryIconLink();
        String name = categoryModellist.get(position).getCategoryName();
        viewHolder.setCategoryName(name);
    }

    @Override
    public int getItemCount() {
        return categoryModellist.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView CategoryIcon;
        private TextView CategoryName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            CategoryIcon = itemView.findViewById(R.id.category_icon);
            CategoryName = itemView.findViewById(R.id.category_name);
        }
        private void setCategoryIcon(){
            ////todo:set categorycons here;
        }
        private  void setCategoryName(){
            CategoryName.setText(name);
        }
    }

}
